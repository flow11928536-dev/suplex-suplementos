# 🖼️ Banners Promocionais

Coloque AQUI os banners promocionais e imagens de destaque de categorias.

Sugestões de arquivos usados nos schemas/SEO:

- `logo.png` — logotipo da loja (Organization / LocalBusiness)
- `og-default.jpg` — imagem padrão de Open Graph / compartilhamento
- banners de campanha (ex: `semana-do-eletro.jpg`)

Tamanho recomendado para Open Graph: **1200 x 630 px**.
