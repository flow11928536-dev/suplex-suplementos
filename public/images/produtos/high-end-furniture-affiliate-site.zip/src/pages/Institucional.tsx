import { SITE } from "../data/products";
import Seo from "../components/Seo";

export function Contato() {
  return (
    <>
      <Seo
        title="Contato | Móveis Marília"
        description="Fale com a Loja de Móveis Marília. Atendimento para Marília-SP e todo o Brasil por e-mail e WhatsApp."
        path="/contato"
        jsonLd={[
          {
            "@context": "https://schema.org",
            "@type": "ContactPage",
            name: "Contato — Móveis Marília",
            url: `${SITE.url}/contato`,
          },
        ]}
      />
      <div className="mx-auto max-w-2xl px-4 py-14 sm:px-6">
        <h1 className="text-3xl font-bold tracking-tight text-stone-900">Fale com a gente</h1>
        <p className="mt-3 text-stone-600">
          Tem uma dúvida sobre um produto ou quer sugerir um guia? Estamos por aqui.
        </p>
        <div className="mt-8 space-y-4">
          <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-widest text-stone-400">E-mail</p>
            <a href={`mailto:${SITE.email}`} className="mt-1 block text-lg font-medium text-stone-900 hover:underline">
              {SITE.email}
            </a>
          </div>
          <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-widest text-stone-400">WhatsApp</p>
            <p className="mt-1 text-lg font-medium text-stone-900">{SITE.whatsapp}</p>
          </div>
          <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-widest text-stone-400">Localização</p>
            <p className="mt-1 text-lg font-medium text-stone-900">{SITE.city} — {SITE.region}, Brasil</p>
            <p className="mt-1 text-sm text-stone-500">Atendemos toda a região de Marília e o estado de São Paulo.</p>
          </div>
        </div>
      </div>
    </>
  );
}

export function Politicas() {
  return (
    <>
      <Seo
        title="Políticas e Transparência | Móveis Marília"
        description="Política de privacidade, uso de links de afiliados e termos da Loja de Móveis Marília. Transparência total com o leitor."
        path="/politicas"
      />
      <div className="mx-auto max-w-2xl px-4 py-14 sm:px-6">
        <h1 className="text-3xl font-bold tracking-tight text-stone-900">Políticas e transparência</h1>

        <div className="mt-8 space-y-8 text-[15px] leading-relaxed text-stone-700">
          <section>
            <h2 className="text-xl font-semibold text-stone-900">Links de afiliados</h2>
            <p className="mt-2">
              A {SITE.name} participa dos programas de afiliados do Mercado Livre e da Shopee. Quando
              você compra por um dos nossos links, podemos receber uma comissão — sem qualquer custo
              adicional para você. Isso mantém o site no ar e independente.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-stone-900">Preços e disponibilidade</h2>
            <p className="mt-2">
              Os preços e o estoque são definidos pelas lojas parceiras e podem mudar a qualquer
              momento. Sempre confirme o valor final na página oficial antes de comprar.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-stone-900">Privacidade</h2>
            <p className="mt-2">
              Não coletamos dados pessoais para login ou cadastro. Utilizamos apenas métricas anônimas
              de navegação para melhorar o conteúdo. Não há carrinho, checkout ou armazenamento de
              dados sensíveis neste site.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-stone-900">Independência editorial</h2>
            <p className="mt-2">
              Nossas recomendações são baseadas em pesquisa, avaliações reais e custo-benefício — não
              no valor da comissão. Indicamos apenas o que realmente vale a pena.
            </p>
          </section>
        </div>
      </div>
    </>
  );
}
