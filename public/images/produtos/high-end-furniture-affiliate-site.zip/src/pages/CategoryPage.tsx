import { Link, useParams } from "react-router-dom";
import {
  CATEGORY_LABELS,
  SITE,
  allCategories,
  getProductsByCategory,
} from "../data/products";
import type { ProductCategory } from "../types";
import ProductGrid from "../components/ProductGrid";
import Seo from "../components/Seo";
import NotFound from "./NotFound";

export default function CategoryPage() {
  const { category = "" } = useParams();
  const isValid = allCategories.includes(category as ProductCategory);

  if (!isValid) return <NotFound />;

  const cat = category as ProductCategory;
  const label = CATEGORY_LABELS[cat];
  const items = getProductsByCategory(cat);
  const path = `/categoria/${cat}`;

  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      name: `${label} em oferta`,
      url: `${SITE.url}${path}`,
      description: `Ofertas selecionadas de ${label} no Mercado Livre e Shopee.`,
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Início", item: SITE.url },
        { "@type": "ListItem", position: 2, name: label, item: `${SITE.url}${path}` },
      ],
    },
  ];

  return (
    <>
      <Seo
        title={`${label} em Oferta | Móveis Marília`}
        description={`Ofertas selecionadas de ${label} com os melhores preços do Mercado Livre e Shopee. Curadoria honesta e entrega para todo o Brasil.`}
        path={path}
        jsonLd={jsonLd}
      />

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <nav aria-label="Trilha de navegação" className="text-sm text-stone-500">
          <ol className="flex flex-wrap items-center gap-1.5">
            <li><Link to="/" className="hover:text-stone-900">Início</Link></li>
            <li aria-hidden="true">/</li>
            <li className="font-medium text-stone-700" aria-current="page">{label}</li>
          </ol>
        </nav>

        <header className="mt-5 max-w-2xl">
          <h1 className="text-3xl font-bold tracking-tight text-stone-900 sm:text-4xl">
            {label} em oferta
          </h1>
          <p className="mt-3 text-stone-500">
            {items.length} {items.length === 1 ? "produto selecionado" : "produtos selecionados"} com
            os melhores preços e avaliações. Clique para verificar estoque e cupons.
          </p>
        </header>

        {/* Chips de categorias */}
        <div className="mt-6 flex flex-wrap gap-2">
          {allCategories.map((c) => (
            <Link
              key={c}
              to={`/categoria/${c}`}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                c === cat
                  ? "bg-stone-900 text-white"
                  : "border border-stone-300 bg-white text-stone-700 hover:bg-stone-50"
              }`}
            >
              {CATEGORY_LABELS[c]}
            </Link>
          ))}
        </div>

        <div className="mt-10">
          <ProductGrid category={cat} priorityFirst />
        </div>
      </div>
    </>
  );
}
