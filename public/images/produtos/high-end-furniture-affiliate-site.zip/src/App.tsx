import { lazy, Suspense } from "react";
import { HashRouter, Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";

// Lazy loading / dynamic imports para reduzir o bundle inicial (Core Web Vitals)
const GuidePage = lazy(() => import("./pages/GuidePage"));
const GuidesIndex = lazy(() => import("./pages/GuidesIndex"));
const CategoryPage = lazy(() => import("./pages/CategoryPage"));
const ConfirmStock = lazy(() => import("./pages/ConfirmStock"));
const NotFound = lazy(() => import("./pages/NotFound"));
const Contato = lazy(() => import("./pages/Institucional").then((m) => ({ default: m.Contato })));
const Politicas = lazy(() => import("./pages/Institucional").then((m) => ({ default: m.Politicas })));

function PageFallback() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center" role="status" aria-label="Carregando">
      <span className="h-8 w-8 animate-spin rounded-full border-2 border-stone-300 border-t-stone-900" />
    </div>
  );
}

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<Home />} />
          <Route
            path="categoria/:category"
            element={
              <Suspense fallback={<PageFallback />}>
                <CategoryPage />
              </Suspense>
            }
          />
          <Route
            path="guias"
            element={
              <Suspense fallback={<PageFallback />}>
                <GuidesIndex />
              </Suspense>
            }
          />
          <Route
            path="guia/:slug"
            element={
              <Suspense fallback={<PageFallback />}>
                <GuidePage />
              </Suspense>
            }
          />
          <Route
            path="confirmar-estoque/:slug"
            element={
              <Suspense fallback={<PageFallback />}>
                <ConfirmStock />
              </Suspense>
            }
          />
          <Route
            path="contato"
            element={
              <Suspense fallback={<PageFallback />}>
                <Contato />
              </Suspense>
            }
          />
          <Route
            path="politicas"
            element={
              <Suspense fallback={<PageFallback />}>
                <Politicas />
              </Suspense>
            }
          />
          <Route
            path="*"
            element={
              <Suspense fallback={<PageFallback />}>
                <NotFound />
              </Suspense>
            }
          />
        </Route>
      </Routes>
    </HashRouter>
  );
}
