import { memo, useMemo } from "react";
import type { ProductGridProps } from "../types";
import { getProductsByCategory, getProductsBySlugs } from "../data/products";
import ProductCard from "./ProductCard";

/**
 * ProductGrid totalmente reutilizável.
 * - Filtra internamente por `category` (uma ou várias) OU por `slugs` (cross-sell).
 * - Aceita `limit`, `title` e `subtitle`.
 * - Garante que jamais apareçam produtos de outra categoria de forma desordenada.
 */
function ProductGridBase({
  category,
  slugs,
  limit,
  title,
  subtitle,
  priorityFirst = false,
}: ProductGridProps) {
  const items = useMemo(() => {
    const base = slugs?.length ? getProductsBySlugs(slugs) : getProductsByCategory(category);
    return typeof limit === "number" ? base.slice(0, limit) : base;
  }, [category, slugs, limit]);

  if (items.length === 0) return null;

  return (
    <section className="py-2" aria-label={title ?? "Lista de produtos"}>
      {(title || subtitle) && (
        <header className="mb-6">
          {title && (
            <h2 className="text-2xl font-semibold tracking-tight text-stone-900 sm:text-3xl">
              {title}
            </h2>
          )}
          {subtitle && <p className="mt-1.5 text-sm text-stone-500 sm:text-base">{subtitle}</p>}
        </header>
      )}

      <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
        {items.map((product, i) => (
          <div
            key={product.id}
            className="animate-[fadeUp_0.6s_ease-out_both]"
            style={{ animationDelay: `${Math.min(i, 7) * 60}ms` }}
          >
            <ProductCard product={product} priority={priorityFirst && i === 0} />
          </div>
        ))}
      </div>
    </section>
  );
}

const ProductGrid = memo(ProductGridBase);
export default ProductGrid;
