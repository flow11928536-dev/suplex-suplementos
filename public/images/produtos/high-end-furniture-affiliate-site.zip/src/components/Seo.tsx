import { Helmet } from "react-helmet-async";
import { SITE } from "../data/products";

interface SeoProps {
  title: string;
  description: string;
  /** Caminho da rota (ex: /guia/moveis-cozinha-pequena) */
  path?: string;
  image?: string;
  type?: "website" | "article" | "product";
  /** Schemas extras (Product, FAQPage, BreadcrumbList, CollectionPage...) */
  jsonLd?: object[];
  noindex?: boolean;
}

const DEFAULT_IMAGE = `${SITE.url}/banners/og-default.jpg`;

// Schemas globais sempre presentes: WebSite + Organization + LocalBusiness
const baseSchemas = (): object[] => [
  {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${SITE.url}/#website`,
    name: SITE.name,
    url: SITE.url,
    inLanguage: "pt-BR",
    description: SITE.description,
    publisher: { "@id": `${SITE.url}/#organization` },
  },
  {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${SITE.url}/#organization`,
    name: SITE.name,
    url: SITE.url,
    logo: { "@type": "ImageObject", url: `${SITE.url}/banners/logo.png` },
    sameAs: ["https://www.mercadolivre.com.br/", "https://shopee.com.br/"],
  },
  {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "@id": `${SITE.url}/#localbusiness`,
    name: SITE.name,
    image: `${SITE.url}/banners/logo.png`,
    url: SITE.url,
    email: SITE.email,
    telephone: SITE.whatsapp,
    priceRange: "R$R$",
    address: {
      "@type": "PostalAddress",
      addressLocality: SITE.city,
      addressRegion: SITE.region,
      addressCountry: SITE.country,
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: SITE.geo.lat,
      longitude: SITE.geo.lng,
    },
    areaServed: [
      { "@type": "City", name: "Marília" },
      { "@type": "State", name: "São Paulo" },
      { "@type": "Country", name: "Brasil" },
    ],
    serviceArea: {
      "@type": "GeoCircle",
      geoMidpoint: {
        "@type": "GeoCoordinates",
        latitude: SITE.geo.lat,
        longitude: SITE.geo.lng,
      },
      geoRadius: 250000,
    },
  },
];

export default function Seo({
  title,
  description,
  path = "/",
  image = DEFAULT_IMAGE,
  type = "website",
  jsonLd = [],
  noindex = false,
}: SeoProps) {
  const canonical = `${SITE.url}${path === "/" ? "" : path}`;
  const fullTitle = title.length > 60 ? title.slice(0, 60) : title;
  const fullDesc = description.length > 155 ? description.slice(0, 155) : description;
  const schemas = [...baseSchemas(), ...jsonLd];

  return (
    <Helmet>
      <html lang="pt-BR" />
      <title>{fullTitle}</title>
      <meta name="description" content={fullDesc} />
      <link rel="canonical" href={canonical} />
      <meta
        name="robots"
        content={noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large"}
      />

      {/* GEO SEO — Marília / São Paulo / Brasil */}
      <meta name="geo.region" content="BR-SP" />
      <meta name="geo.placename" content="Marília, São Paulo" />
      <meta name="geo.position" content={`${SITE.geo.lat};${SITE.geo.lng}`} />
      <meta name="ICBM" content={`${SITE.geo.lat}, ${SITE.geo.lng}`} />

      {/* Open Graph */}
      <meta property="og:type" content={type} />
      <meta property="og:site_name" content={SITE.name} />
      <meta property="og:locale" content="pt_BR" />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={fullDesc} />
      <meta property="og:url" content={canonical} />
      <meta property="og:image" content={image} />

      {/* Twitter Cards */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={fullDesc} />
      <meta name="twitter:image" content={image} />

      {/* JSON-LD encadeado */}
      {schemas.map((schema, i) => (
        <script key={i} type="application/ld+json">
          {JSON.stringify(schema)}
        </script>
      ))}
    </Helmet>
  );
}
