import { useState } from "react";
import { cn } from "../utils/cn";

interface SmartImageProps {
  src: string;
  alt: string;
  className?: string;
  /** Define LCP: primeira imagem visível usa priority (eager + high) */
  priority?: boolean;
  sizes?: string;
  /** Proporção para reservar espaço e evitar CLS */
  aspect?: string;
}

/**
 * Substituto do <Image /> do Next.js:
 * - Reserva espaço (aspect) -> elimina Layout Shift (CLS)
 * - placeholder "blur" via gradiente até o load -> fade-in suave
 * - loading lazy nos não-prioritários, eager + fetchpriority no LCP
 */
export default function SmartImage({
  src,
  alt,
  className,
  priority = false,
  sizes = "(max-width: 768px) 100vw, 25vw",
  aspect = "4 / 3",
}: SmartImageProps) {
  const [loaded, setLoaded] = useState(false);

  return (
    <div
      className="relative w-full overflow-hidden bg-gradient-to-br from-stone-200 via-stone-100 to-stone-200"
      style={{ aspectRatio: aspect }}
    >
      {!loaded && <div className="absolute inset-0 animate-pulse bg-stone-200/70" aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        sizes={sizes}
        loading={priority ? "eager" : "lazy"}
        decoding="async"
        // @ts-expect-error fetchpriority é válido no DOM
        fetchpriority={priority ? "high" : "auto"}
        onLoad={() => setLoaded(true)}
        className={cn(
          "h-full w-full object-cover transition-all duration-700 ease-out",
          loaded ? "scale-100 opacity-100 blur-0" : "scale-105 opacity-0 blur-md",
          className
        )}
      />
    </div>
  );
}
