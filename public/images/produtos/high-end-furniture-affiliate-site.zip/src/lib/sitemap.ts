import { SITE, allCategories, products } from "../data/products";
import { ALL_GUIDE_SLUGS } from "../data/guides";

export interface SitemapEntry {
  url: string;
  changefreq: "daily" | "weekly" | "monthly";
  priority: number;
}

/**
 * Equivalente ao src/app/sitemap.ts do Next.js.
 * Varre dinamicamente a array central de produtos + guias + categorias.
 */
export function buildSitemap(): SitemapEntry[] {
  const base = SITE.url;
  const entries: SitemapEntry[] = [
    { url: `${base}/`, changefreq: "daily", priority: 1.0 },
    { url: `${base}/guias`, changefreq: "weekly", priority: 0.8 },
    { url: `${base}/contato`, changefreq: "monthly", priority: 0.4 },
    { url: `${base}/politicas`, changefreq: "monthly", priority: 0.3 },
  ];

  // Categorias
  allCategories.forEach((cat) =>
    entries.push({ url: `${base}/categoria/${cat}`, changefreq: "weekly", priority: 0.7 })
  );

  // Produtos + páginas de confirmação de estoque
  products.forEach((p) => {
    entries.push({
      url: `${base}/confirmar-estoque/${p.slug}`,
      changefreq: "weekly",
      priority: 0.9,
    });
  });

  // Guias dinâmicos
  ALL_GUIDE_SLUGS.forEach((slug) =>
    entries.push({ url: `${base}/guia/${slug}`, changefreq: "weekly", priority: 0.8 })
  );

  return entries;
}

/** Gera o XML completo do sitemap */
export function buildSitemapXml(): string {
  const today = new Date().toISOString().split("T")[0];
  const urls = buildSitemap()
    .map(
      (e) =>
        `  <url>\n    <loc>${e.url}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>${e.changefreq}</changefreq>\n    <priority>${e.priority.toFixed(1)}</priority>\n  </url>`
    )
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

/** Equivalente ao src/app/robots.ts do Next.js */
export function buildRobotsTxt(): string {
  return [
    "User-agent: *",
    "Allow: /",
    "Disallow: /confirmar-estoque/",
    "",
    "# IAs e crawlers de busca generativa são bem-vindos ao conteúdo dos guias",
    "User-agent: GPTBot",
    "Allow: /",
    "User-agent: PerplexityBot",
    "Allow: /",
    "User-agent: Google-Extended",
    "Allow: /",
    "",
    `Sitemap: ${SITE.url}/sitemap.xml`,
    "",
  ].join("\n");
}
