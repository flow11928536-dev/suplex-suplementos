import type { Guide, GuideBlock, FaqItem, ProductCategory } from "../types";

// ============================================================================
//  MOTOR DE CONTEÚDO — GUIAS DINÂMICOS (/guia/[slug])
//  5 clusters mapeados. O slug "moveis-cozinha-pequena" é o modelo completo.
// ============================================================================

/** Mapeamento de cômodo -> categorias de cross-sell (lógica nativa) */
export const CROSS_SELL: Record<string, ProductCategory[]> = {
  cozinha: ["cozinhas", "eletrodomesticos"],
  sala: ["paineis", "sofas", "eletrodomesticos"],
  quarto: ["quartos", "guarda-roupas", "eletrodomesticos"],
  "area-externa": ["area-externa", "eletrodomesticos"],
  "home-office": ["home-office", "eletrodomesticos"],
};

/** Lista de slugs por cluster — base do generateStaticParams */
export const GUIDE_CLUSTERS: { cluster: number; titulo: string; slugs: string[] }[] = [
  {
    cluster: 1,
    titulo: "Guias por Tipo (Conversão)",
    slugs: [
      "moveis-area-externa",
      "moveis-planejados-vs-modulados",
      "moveis-home-office-barato",
      "moveis-cozinha-pequena",
      "moveis-varanda-jardim",
      "moveis-quarto-casal",
      "moveis-quarto-infantil",
    ],
  },
  {
    cluster: 2,
    titulo: "Dúvidas e Dicas (Tráfego + GEO)",
    slugs: [
      "por-que-moveis-estalam",
      "como-envelopar-moveis",
      "mdf-vs-mdp-diferenca",
      "como-restaurar-moveis-madeira",
      "como-pintar-moveis-madeira",
    ],
  },
  {
    cluster: 3,
    titulo: "Comparação de Lojas",
    slugs: [
      "melhores-lojas-moveis-online",
      "moveis-outlet-pequenos-defeitos",
      "moveis-frete-gratis-entrega-rapida",
    ],
  },
  {
    cluster: 4,
    titulo: "SEO Local",
    slugs: ["moveis-usados-perto-de-mim", "lojas-moveis-sao-paulo", "lojas-moveis-curitiba"],
  },
  {
    cluster: 5,
    titulo: "Evergreen Alto Volume",
    slugs: [
      "tipos-madeira-para-moveis",
      "quanto-custa-moveis-planejados",
      "moveis-de-pallet-como-fazer",
      "moveis-industriais-sala",
    ],
  },
];

export const ALL_GUIDE_SLUGS: string[] = GUIDE_CLUSTERS.flatMap((c) => c.slugs);

const clusterOf = (slug: string): number =>
  GUIDE_CLUSTERS.find((c) => c.slugs.includes(slug))?.cluster ?? 1;

// ----------------------------------------------------------------------------
//  GUIA MODELO COMPLETO (1.000+ palavras) — moveis-cozinha-pequena
// ----------------------------------------------------------------------------
const guiaCozinhaPequena: Guide = {
  slug: "moveis-cozinha-pequena",
  cluster: 1,
  keyword: "móveis para cozinha pequena",
  h1: "Móveis para Cozinha Pequena: Guia Completo para Aproveitar Cada Centímetro",
  intro:
    "Escolher móveis para cozinha pequena é, antes de tudo, uma decisão de espaço. Aqui você vai entender o que realmente funciona em metragens apertadas — sem cair em armadilhas de marketing.",
  heroImage:
    "https://images.pexels.com/photos/7060816/pexels-photo-7060816.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  heroAlt:
    "Cozinha pequena moderna com armários brancos e amadeirados aproveitando bem o espaço",
  seoTitle: "Móveis para Cozinha Pequena: Guia Completo 2026",
  seoDescription:
    "Guia honesto de móveis para cozinha pequena: como medir, organizar na vertical, escolher armários compactos e os eletrodomésticos certos.",
  ctaSlug: "cozinha-compacta-madesa-glamy",
  blocks: [
    {
      type: "text",
      paragraphs: [
        "Vou ser direto com você: o segredo de uma cozinha pequena funcional não é comprar o armário mais bonito da loja, e sim escolher móveis que conversam com a planta do seu ambiente. Cada centímetro conta, e a diferença entre uma cozinha sufocante e uma cozinha gostosa de usar está nos detalhes de medida e organização.",
        "Antes de qualquer compra, pegue uma trena e anote três medidas: largura da parede principal, altura do pé-direito e a distância livre entre paredes opostas. Essas três informações vão evitar o erro mais comum de quem compra móveis online — receber uma cozinha que simplesmente não cabe.",
      ],
    },
    {
      type: "grid",
      title: "Cozinhas Compactas Mais Vendidas",
      subtitle: "Modelos modulados pensados para metragens pequenas",
      category: "cozinhas",
      limit: 2,
    },
    {
      type: "text",
      heading: "Como medir e planejar antes de comprar",
      level: 2,
      paragraphs: [
        "Cozinha pequena pede planejamento na vertical. Em vez de espalhar móveis pelo chão, suba: armários aéreos até o teto, prateleiras altas e ganchos liberam a bancada e dão sensação de amplitude.",
        "Outra dica de ouro é respeitar o triângulo de trabalho — geladeira, pia e fogão devem formar um triângulo curto, com no máximo dois passos entre cada um. Isso torna o dia a dia muito mais ágil.",
      ],
      bullets: [
        "Meça largura, altura e profundidade disponíveis antes de escolher qualquer módulo.",
        "Prefira armários até o teto para ganhar armazenamento sem ocupar área útil.",
        "Deixe ao menos 90 cm de circulação livre na frente da bancada.",
        "Use cores claras e portas com puxadores embutidos para ampliar visualmente.",
      ],
    },
    {
      type: "grid",
      title: "Eletrodomésticos que Cabem na Cozinha Pequena",
      subtitle: "Cross-sell inteligente: geladeira, micro-ondas e air fryer compactos",
      slugs: [
        "geladeira-frost-free-frost-360l",
        "micro-ondas-30l-espelhado",
        "airfryer-fritadeira-eletrica-5l",
      ],
    },
    {
      type: "text",
      heading: "Materiais: MDP, MDF e o que esperar de cada um",
      level: 2,
      paragraphs: [
        "A maioria das cozinhas compactas de bom custo-benefício é feita em MDP, que aguenta bem o uso doméstico e tem preço acessível. Já o MDF oferece acabamento superior e suporta usinagens e detalhes, custando um pouco mais.",
        "Em cozinha, o ponto de atenção é a umidade. Procure módulos com revestimento BP (baixa pressão) bem vedado nas bordas e pés reguláveis que afastam o móvel do piso molhado.",
      ],
    },
    {
      type: "callout",
      variant: "dica",
      title: "💡 Dica de quem já montou várias",
      text: "Compre a cozinha em módulos separados sempre que possível. Assim você adapta a combinação exata ao seu espaço e troca apenas uma peça no futuro, em vez do conjunto inteiro.",
    },
    {
      type: "grid",
      title: "Aproveite Também",
      subtitle: "Soluções de organização e apoio para liberar a bancada",
      slugs: ["armario-aereo-cozinha-3-portas", "fogao-5-bocas-mesa-vidro"],
    },
    {
      type: "text",
      heading: "Comparativo de soluções por tamanho de cozinha",
      level: 2,
      paragraphs: [
        "Para facilitar sua decisão, montei uma tabela rápida cruzando a metragem da cozinha com o tipo de conjunto que melhor se encaixa. Use como ponto de partida e ajuste conforme suas medidas reais.",
      ],
      table: {
        headers: ["Tamanho da cozinha", "Conjunto ideal", "Nº de portas", "Faixa de preço"],
        rows: [
          ["Até 4 m²", "Cozinha compacta 1 peça", "8 a 11 portas", "R$ 600 – R$ 1.000"],
          ["4 a 7 m²", "Compacta + aéreo extra", "11 a 14 portas", "R$ 1.000 – R$ 1.600"],
          ["7 a 10 m²", "Modulada em L", "14 a 18 portas", "R$ 1.600 – R$ 2.800"],
          ["Acima de 10 m²", "Modulada + ilha", "18+ portas", "R$ 2.800+"],
        ],
      },
    },
    {
      type: "callout",
      variant: "alerta",
      title: "⚠️ Cuidado na hora de comprar online",
      text: "Confira sempre se o tampo de pia e a cuba estão inclusos. Muitos anúncios mostram a cozinha completa na foto, mas a pia é vendida à parte. Leia a descrição com atenção.",
    },
    {
      type: "grid",
      title: "Melhor Custo-Benefício",
      subtitle: "Nossa seleção campeã de avaliações para cozinha pequena",
      slugs: ["cozinha-compacta-madesa-glamy", "armario-aereo-cozinha-3-portas"],
    },
    {
      type: "text",
      heading: "Erros que fazem a cozinha pequena parecer ainda menor",
      level: 2,
      paragraphs: [
        "O primeiro erro é o excesso de cores escuras e muitos objetos à mostra. Em espaços pequenos, menos é mais: portas fechadas escondem a bagunça e acalmam o visual.",
        "O segundo é ignorar a iluminação. Uma fita de LED sob os armários aéreos ilumina a bancada e cria profundidade, fazendo a cozinha parecer maior do que é.",
        "Por fim, não superlote a bancada com eletrodomésticos. Escolha os essenciais — micro-ondas e air fryer compactos resolvem 80% das refeições do dia a dia sem tomar todo o espaço.",
      ],
    },
  ],
  faq: [
    {
      question: "Qual o melhor móvel para cozinha pequena?",
      answer:
        "Cozinhas compactas moduladas em MDP, com armários aéreos até o teto, são as mais indicadas. Elas aproveitam a vertical e cabem em metragens a partir de 4 m².",
    },
    {
      question: "Cozinha de MDP é resistente à umidade?",
      answer:
        "Sim, desde que tenha revestimento bem vedado nas bordas e pés reguláveis para afastar do piso. Evite contato direto e prolongado com água para durar mais.",
    },
    {
      question: "Quanto custa mobiliar uma cozinha pequena?",
      answer:
        "Uma cozinha compacta de qualidade custa entre R$ 600 e R$ 1.600. Somando geladeira, fogão e micro-ondas, o investimento total fica em torno de R$ 3.000 a R$ 5.000.",
    },
    {
      question: "Vale a pena cozinha planejada ou modulada para espaço pequeno?",
      answer:
        "Para a maioria, a modulada vence: custa muito menos, instala rápido e já cabe bem em cozinhas pequenas. A planejada só compensa em plantas muito irregulares.",
    },
    {
      question: "Como organizar uma cozinha pequena para caber tudo?",
      answer:
        "Use a vertical com aéreos e prateleiras, organizadores internos nas gavetas e ganchos nas laterais. Mantenha a bancada livre e guarde o que usa menos no alto.",
    },
  ],
};

// ----------------------------------------------------------------------------
//  GERADOR ESTRUTURADO PARA OS DEMAIS SLUGS DOS 5 CLUSTERS
// ----------------------------------------------------------------------------
interface GuideSeed {
  keyword: string;
  h1: string;
  intro: string;
  heroImage: string;
  heroAlt: string;
  cross: ProductCategory[];
  ctaSlug: string;
  sub1: { heading: string; paragraphs: string[]; bullets?: string[] };
  sub2: { heading: string; paragraphs: string[] };
  callout: { variant: "dica" | "alerta"; title: string; text: string };
  sub3: { heading: string; paragraphs: string[] };
  faq: FaqItem[];
  grid1Cat: ProductCategory;
  bestSlugs: string[];
}

const IMG = {
  cozinha:
    "https://images.pexels.com/photos/7535073/pexels-photo-7535073.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  quarto:
    "https://images.pexels.com/photos/7535012/pexels-photo-7535012.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  sala:
    "https://images.pexels.com/photos/6987730/pexels-photo-6987730.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  office:
    "https://images.pexels.com/photos/31213677/pexels-photo-31213677.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  externa:
    "https://images.pexels.com/photos/8135496/pexels-photo-8135496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
};

const titleCase = (slug: string): string =>
  slug
    .split("-")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");

const genericFaq = (keyword: string): FaqItem[] => [
  {
    question: `Vale a pena investir em ${keyword}?`,
    answer: `Sim. Com a curadoria certa de marcas e lojas, ${keyword} entrega bom custo-benefício e durabilidade para o uso doméstico.`,
  },
  {
    question: `Como escolher ${keyword} pela internet com segurança?`,
    answer:
      "Compre por vendedores oficiais (Mercado Livre e Shopee), confira avaliações reais e leia a descrição completa antes de fechar.",
  },
  {
    question: `Qual a faixa de preço de ${keyword}?`,
    answer:
      "Os preços variam bastante conforme material e tamanho. Sempre compare ao menos três anúncios e fique atento a cupons e frete grátis.",
  },
  {
    question: `${titleCase(keyword)} de MDP é durável?`,
    answer:
      "O MDP aguenta bem o uso residencial quando bem montado e mantido longe de umidade. Para acabamento premium, prefira o MDF.",
  },
  {
    question: `Como cuidar e conservar ${keyword}?`,
    answer:
      "Limpe com pano levemente úmido, evite produtos abrasivos e mantenha longe de calor e água. Reaperte parafusos a cada seis meses.",
  },
];

const SEEDS: Record<string, GuideSeed> = {
  "moveis-area-externa": {
    keyword: "móveis para área externa",
    h1: "Móveis para Área Externa: Como Escolher Peças Resistentes ao Tempo",
    intro:
      "Montar uma área externa gostosa começa por móveis que aguentam sol e chuva. Veja como escolher sem se arrepender depois.",
    heroImage: IMG.externa,
    heroAlt: "Área externa moderna com móveis resistentes ao tempo",
    cross: CROSS_SELL["area-externa"],
    ctaSlug: "conjunto-mesa-cadeiras-area-externa",
    grid1Cat: "area-externa",
    bestSlugs: ["conjunto-mesa-cadeiras-area-externa"],
    sub1: {
      heading: "Quais materiais resistem ao sol e à chuva",
      paragraphs: [
        "Para área externa, fuja de materiais que incham com a umidade. Fibra sintética, alumínio e madeira tratada são as escolhas mais seguras.",
        "O alumínio não enferruja e é leve; a fibra sintética imita o vime sem desbotar; a madeira tratada pede manutenção, mas envelhece com charme.",
      ],
      bullets: [
        "Fibra sintética: leve, não desbota e resiste à chuva.",
        "Alumínio: não enferruja e é fácil de transportar.",
        "Madeira tratada (cumaru, eucalipto): rústica e firme.",
      ],
    },
    sub2: {
      heading: "Como montar uma área gourmet completa",
      paragraphs: [
        "Além de mesa e cadeiras, pense em quem vai receber. Uma churrasqueira elétrica e um bom cooler transformam qualquer varanda em ponto de encontro.",
        "Caixas de som bluetooth resistentes à água fecham a experiência sem complicação de instalação.",
      ],
    },
    callout: {
      variant: "dica",
      title: "💡 Dica",
      text: "Use almofadas com tecido impermeável e capas de proteção. Elas dobram a vida útil dos estofados de área externa.",
    },
    sub3: {
      heading: "Comparativo de materiais para área externa",
      paragraphs: [
        "Veja lado a lado os materiais mais comuns para decidir conforme seu clima e nível de exposição ao tempo.",
      ],
    },
    faq: genericFaq("móveis para área externa"),
  },
  "moveis-home-office-barato": {
    keyword: "móveis para home office barato",
    h1: "Móveis para Home Office Barato: Monte um Escritório Produtivo Gastando Pouco",
    intro:
      "Dá para montar um home office confortável e bonito sem estourar o orçamento. Veja as peças que realmente fazem diferença.",
    heroImage: IMG.office,
    heroAlt: "Home office compacto e organizado com escrivaninha e cadeira",
    cross: CROSS_SELL["home-office"],
    ctaSlug: "escrivaninha-home-office-gavetas",
    grid1Cat: "home-office",
    bestSlugs: ["escrivaninha-home-office-gavetas", "cadeira-gamer-ergonomica-reclinavel"],
    sub1: {
      heading: "O essencial: mesa e cadeira certas",
      paragraphs: [
        "Antes de decorar, invista no básico que protege seu corpo: uma escrivaninha na altura certa e uma cadeira ergonômica.",
        "Mesa muito baixa força o pescoço; cadeira ruim detona a lombar em poucas semanas. Esses dois itens são prioridade absoluta.",
      ],
      bullets: [
        "Mesa entre 72 e 75 cm de altura é o padrão ergonômico.",
        "Cadeira com apoio lombar e regulagem de altura é indispensável.",
        "Prefira gavetas para esconder cabos e papelada.",
      ],
    },
    sub2: {
      heading: "Tecnologia que aumenta a produtividade",
      paragraphs: [
        "Com o mobiliário resolvido, um monitor extra, webcam e headset elevam o nível das reuniões sem custar uma fortuna.",
        "Uma impressora compacta fecha o setup de quem precisa de documentos no dia a dia.",
      ],
    },
    callout: {
      variant: "dica",
      title: "💡 Dica",
      text: "Posicione a mesa perto de uma janela. Luz natural reduz a fadiga ocular e melhora o astral durante o expediente.",
    },
    sub3: {
      heading: "Quanto investir em cada item",
      paragraphs: ["Um guia rápido de prioridade de gastos para montar o home office por etapas."],
    },
    faq: genericFaq("móveis para home office barato"),
  },
  "moveis-quarto-casal": {
    keyword: "móveis para quarto de casal",
    h1: "Móveis para Quarto de Casal: Conforto, Espaço e Organização",
    intro:
      "O quarto de casal precisa equilibrar descanso e armazenamento. Veja como escolher cama, guarda-roupa e o clima ideal para dormir bem.",
    heroImage: IMG.quarto,
    heroAlt: "Quarto de casal moderno com guarda-roupa embutido e cama confortável",
    cross: CROSS_SELL["quarto"],
    ctaSlug: "guarda-roupa-casal-6-portas-mdp",
    grid1Cat: "guarda-roupas",
    bestSlugs: ["guarda-roupa-casal-6-portas-mdp", "cama-box-bau-casal-bicama"],
    sub1: {
      heading: "Guarda-roupa: quantas portas você realmente precisa",
      paragraphs: [
        "Para casal, o ideal é a partir de 6 portas, com divisão de cabideiros, gavetas e prateleiras. Espelho central ajuda e amplia o ambiente.",
        "Meça a parede antes: um roupeiro grande demais engole o quarto e atrapalha a circulação.",
      ],
      bullets: [
        "6 a 8 portas atendem bem a maioria dos casais.",
        "Gavetas internas valem mais que portas extras.",
        "Espelho embutido amplia visualmente o quarto.",
      ],
    },
    sub2: {
      heading: "Cama box com baú: o segredo do espaço extra",
      paragraphs: [
        "Em quartos sem closet, a cama box com baú resolve o armazenamento de roupas de cama e itens fora de estação.",
        "Para noites melhores, um ar-condicionado split silencioso faz toda a diferença no verão.",
      ],
    },
    callout: {
      variant: "dica",
      title: "💡 Dica",
      text: "Invista no colchão antes da decoração. É ele que define a qualidade do seu sono — o resto é complemento.",
    },
    sub3: {
      heading: "Comparativo de tamanhos de guarda-roupa",
      paragraphs: ["Use a tabela para cruzar o tamanho do quarto com o roupeiro ideal."],
    },
    faq: genericFaq("móveis para quarto de casal"),
  },
  "moveis-industriais-sala": {
    keyword: "móveis industriais para sala",
    h1: "Móveis Industriais para Sala: Estilo Urbano com Aço e Madeira",
    intro:
      "O estilo industrial une ferro, madeira e linhas cruas para uma sala moderna e cheia de personalidade. Veja como acertar na composição.",
    heroImage: IMG.sala,
    heroAlt: "Sala de estar com móveis de estilo industrial em madeira e metal",
    cross: CROSS_SELL["sala"],
    ctaSlug: "painel-rack-tv-65-polegadas",
    grid1Cat: "paineis",
    bestSlugs: ["painel-rack-tv-65-polegadas", "sofa-retratil-3-lugares-suede"],
    sub1: {
      heading: "Os pilares do estilo industrial",
      paragraphs: [
        "O industrial vive de contrastes: estruturas de metal preto com tampos de madeira clara, tijolinho aparente e iluminação pendente.",
        "Em casa, comece pelo rack ou painel com pés de ferro e vá somando peças aos poucos.",
      ],
      bullets: [
        "Estrutura metálica preta + madeira natural.",
        "Iluminação pendente com lâmpadas filamento.",
        "Tons neutros: cinza, preto, marrom e off-white.",
      ],
    },
    sub2: {
      heading: "Conforto sem perder a pegada urbana",
      paragraphs: [
        "Um sofá de linhas retas em tecido encorpado equilibra a frieza do metal e garante o conforto da sala.",
        "Complete o ambiente com uma boa TV no painel e um ventilador de teto de design para os dias quentes.",
      ],
    },
    callout: {
      variant: "alerta",
      title: "⚠️ Cuidado",
      text: "Não exagere no metal. Sem madeira e têxteis para equilibrar, a sala industrial fica fria e pouco acolhedora.",
    },
    sub3: {
      heading: "Comparativo de peças-chave",
      paragraphs: ["Confira as peças que mais entregam o visual industrial pelo melhor custo."],
    },
    faq: genericFaq("móveis industriais para sala"),
  },
  "mdf-vs-mdp-diferenca": {
    keyword: "diferença entre MDF e MDP",
    h1: "MDF vs MDP: a Diferença que Define a Durabilidade dos Seus Móveis",
    intro:
      "MDF e MDP parecem iguais na loja, mas se comportam de formas diferentes. Entenda qual escolher para cada móvel da casa.",
    heroImage: IMG.cozinha,
    heroAlt: "Comparação de painéis de madeira MDF e MDP usados em móveis",
    cross: CROSS_SELL["cozinha"],
    ctaSlug: "guarda-roupa-casal-6-portas-mdp",
    grid1Cat: "guarda-roupas",
    bestSlugs: ["guarda-roupa-casal-6-portas-mdp", "cozinha-compacta-madesa-glamy"],
    sub1: {
      heading: "Como cada material é fabricado",
      paragraphs: [
        "O MDF é feito de fibras de madeira prensadas, resultando em uma placa homogênea e densa. O MDP usa partículas maiores, com miolo menos uniforme.",
        "Essa diferença de estrutura explica tudo: o MDF aceita usinagem e detalhes; o MDP é mais econômico e ideal para superfícies retas.",
      ],
      bullets: [
        "MDF: fibras finas, denso, aceita curvas e frisos.",
        "MDP: partículas maiores, mais barato, ideal para peças retas.",
        "Ambos recebem revestimento BP para acabamento.",
      ],
    },
    sub2: {
      heading: "Qual escolher para cada cômodo",
      paragraphs: [
        "Para portas com detalhes e móveis de cozinha sob medida, o MDF compensa. Para guarda-roupas e estantes retas, o MDP entrega ótimo custo-benefício.",
        "O importante é que o móvel tenha bordas bem vedadas, independentemente do material.",
      ],
    },
    callout: {
      variant: "dica",
      title: "💡 Dica",
      text: "Na hora de comparar preços, verifique a espessura da placa. Móveis de 18 mm são bem mais firmes que os de 15 mm.",
    },
    sub3: {
      heading: "Tabela comparativa MDF x MDP",
      paragraphs: ["Resumo prático para decidir em segundos qual material faz sentido para você."],
    },
    faq: genericFaq("diferença entre MDF e MDP"),
  },
};

/** Seed padrão para slugs ainda não detalhados (garante build estático completo) */
const defaultSeed = (slug: string): GuideSeed => {
  const keyword = titleCase(slug).toLowerCase();
  return {
    keyword,
    h1: `${titleCase(slug)}: Guia Prático e Honesto`,
    intro: `Tudo o que você precisa saber sobre ${keyword} de forma direta, sem enrolação e com foco no que realmente importa na hora de decidir.`,
    heroImage: IMG.sala,
    heroAlt: `Ambiente decorado ilustrando ${keyword}`,
    cross: CROSS_SELL["sala"],
    ctaSlug: "painel-rack-tv-65-polegadas",
    grid1Cat: "sofas",
    bestSlugs: ["sofa-retratil-3-lugares-suede", "painel-rack-tv-65-polegadas"],
    sub1: {
      heading: `O que considerar sobre ${keyword}`,
      paragraphs: [
        `Quando o assunto é ${keyword}, o primeiro passo é entender sua necessidade real de uso, espaço e orçamento.`,
        "Decisões boas vêm de medir o ambiente, comparar materiais e ler avaliações de quem já comprou.",
      ],
      bullets: [
        "Defina o orçamento antes de pesquisar.",
        "Meça o espaço disponível com precisão.",
        "Compare ao menos três anúncios diferentes.",
      ],
    },
    sub2: {
      heading: "Como comprar com segurança pela internet",
      paragraphs: [
        "Prefira vendedores oficiais no Mercado Livre e na Shopee, com boa reputação e muitas avaliações.",
        "Confira prazo de entrega, política de troca e se a montagem está inclusa.",
      ],
    },
    callout: {
      variant: "dica",
      title: "💡 Dica",
      text: "Ative os alertas de preço e fique de olho em cupons. Pequenos descontos somados fazem grande diferença no total.",
    },
    sub3: {
      heading: "Comparativo rápido de opções",
      paragraphs: ["Use a seleção abaixo como ponto de partida para sua escolha."],
    },
    faq: genericFaq(keyword),
  };
};

const buildFromSeed = (slug: string, seed: GuideSeed): Guide => {
  const comodo = seed.cross[0];
  const blocks: GuideBlock[] = [
    {
      type: "text",
      paragraphs: [seed.intro, seed.sub1.paragraphs[0]],
    },
    {
      type: "grid",
      title: "Destaques Selecionados",
      subtitle: "As opções principais para o seu projeto",
      category: seed.grid1Cat,
      limit: 2,
    },
    {
      type: "text",
      heading: seed.sub1.heading,
      level: 2,
      paragraphs: seed.sub1.paragraphs,
      bullets: seed.sub1.bullets,
    },
    {
      type: "grid",
      title: "Combina Muito Bem",
      subtitle: "Cross-sell de eletrodomésticos e itens relacionados",
      category: seed.cross,
      limit: 3,
    },
    {
      type: "text",
      heading: seed.sub2.heading,
      level: 2,
      paragraphs: seed.sub2.paragraphs,
    },
    {
      type: "callout",
      variant: seed.callout.variant,
      title: seed.callout.title,
      text: seed.callout.text,
    },
    {
      type: "grid",
      title: "Aproveite Também",
      subtitle: "Ofertas complementares que vão bem com a sua escolha",
      category: comodo,
      limit: 3,
    },
    {
      type: "text",
      heading: seed.sub3.heading,
      level: 2,
      paragraphs: seed.sub3.paragraphs,
      table: {
        headers: ["Critério", "Opção econômica", "Opção premium"],
        rows: [
          ["Material", "MDP 15 mm", "MDF 18 mm"],
          ["Acabamento", "BP padrão", "BP texturizado / laca"],
          ["Durabilidade", "Boa para uso diário", "Alta, longo prazo"],
          ["Faixa de preço", "Mais acessível", "Investimento maior"],
        ],
      },
    },
    {
      type: "grid",
      title: "Melhor Custo-Benefício",
      subtitle: "Nossa seleção campeã de avaliações",
      slugs: seed.bestSlugs,
    },
  ];

  return {
    slug,
    cluster: clusterOf(slug),
    keyword: seed.keyword,
    h1: seed.h1,
    intro: seed.intro,
    heroImage: seed.heroImage,
    heroAlt: seed.heroAlt,
    seoTitle: `${seed.h1.split(":")[0]} | Móveis Marília`.slice(0, 60),
    seoDescription: seed.intro.slice(0, 155),
    ctaSlug: seed.ctaSlug,
    blocks,
    faq: seed.faq,
  };
};

/** Retorna o guia completo de um slug (modelo dedicado ou gerado estruturado) */
export const getGuide = (slug: string): Guide | undefined => {
  if (!ALL_GUIDE_SLUGS.includes(slug)) return undefined;
  if (slug === "moveis-cozinha-pequena") return guiaCozinhaPequena;
  const seed = SEEDS[slug] ?? defaultSeed(slug);
  return buildFromSeed(slug, seed);
};

/** Metadados leves de todos os guias (para sitemap, listagens e prefetch) */
export const getAllGuidesMeta = () =>
  ALL_GUIDE_SLUGS.map((slug) => {
    const g = getGuide(slug)!;
    return { slug, h1: g.h1, keyword: g.keyword, cluster: g.cluster, heroImage: g.heroImage };
  });
