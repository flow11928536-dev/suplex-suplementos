import type { Product, ProductCategory } from "../types";

// ============================================================================
//  FONTE DA VERDADE — TODOS OS PRODUTOS DO SITE FICAM SOMENTE AQUI
//  Loja de Móveis Marília — https://lojademoveismarilia.com.br
// ----------------------------------------------------------------------------
//  COMO PUBLICAR UM PRODUTO:
//   1. Cole o link de afiliado em `affiliateLink`     -> // INSERIR_AQUI_O_LINK_DE_AFILIADO
//   2. Salve a foto em /public/imagens/produtos/      -> // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
//   3. Ajuste `imageFile` para /imagens/produtos/seu-arquivo.webp
//  O campo `displayImage` é apenas uma imagem de demonstração (stock) e pode
//  ser removido depois que você inserir a foto real em `imageFile`.
// ============================================================================

export const SITE = {
  url: "https://lojademoveismarilia.com.br",
  name: "Loja de Móveis Marília",
  shortName: "Móveis Marília",
  description:
    "Curadoria de móveis e eletrodomésticos de alto padrão com os melhores preços do Mercado Livre e Shopee. Guias honestos e ofertas selecionadas.",
  city: "Marília",
  region: "SP",
  country: "BR",
  geo: { lat: -22.2171, lng: -49.9501 },
  whatsapp: "+55 14 99999-0000",
  email: "contato@lojademoveismarilia.com.br",
} as const;

export const CATEGORY_LABELS: Record<ProductCategory, string> = {
  cozinhas: "Cozinhas",
  "guarda-roupas": "Guarda-Roupas",
  paineis: "Painéis e Racks",
  sofas: "Sofás",
  "home-office": "Home Office",
  "area-externa": "Área Externa",
  quartos: "Quartos",
  eletrodomesticos: "Eletrodomésticos",
};

export const products: Product[] = [
  // ----------------------------- COZINHAS -----------------------------------
  {
    id: "p-001",
    slug: "cozinha-compacta-madesa-glamy",
    category: "cozinhas",
    name: "Cozinha Compacta Madesa Glamy 11 Portas MDP",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/cozinha-compacta-madesa-glamy.webp",
    displayImage:
      "https://images.pexels.com/photos/7060816/pexels-photo-7060816.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Cozinha compacta Madesa Glamy branca com 11 portas instalada em apartamento moderno",
    rating: 4.7,
    reviews: 3184,
    discount: 32,
    price: 949.9,
    originalPrice: 1399.9,
    badge: "Mais Vendido",
    platform: "Mercado Livre",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://www.mercadolivre.com.br/",
    descricao:
      "Cozinha modulada de baixo custo em MDP com 11 portas e 3 gavetas. Ideal para cozinhas pequenas, otimiza cada centímetro com tampo de pia e armário aéreo inclusos.",
    marca: "Madesa",
    keywords: [
      "cozinha compacta",
      "cozinha madesa",
      "cozinha pequena barata",
      "armário de cozinha mdp",
    ],
    seoTitle: "Cozinha Compacta Madesa Glamy 11 Portas | Oferta",
    seoDescription:
      "Cozinha compacta Madesa Glamy com 11 portas por R$ 949,90. Ideal para cozinha pequena. Frete grátis e parcelamento no Mercado Livre.",
  },
  {
    id: "p-002",
    slug: "armario-aereo-cozinha-3-portas",
    category: "cozinhas",
    name: "Armário Aéreo de Cozinha 3 Portas com Nichos",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/armario-aereo-cozinha-3-portas.webp",
    displayImage:
      "https://images.pexels.com/photos/8146322/pexels-photo-8146322.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Armário aéreo de cozinha de madeira com três portas e nichos abertos",
    rating: 4.6,
    reviews: 1422,
    discount: 25,
    price: 389.9,
    originalPrice: 519.9,
    badge: "Espaço Inteligente",
    platform: "Shopee",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://shopee.com.br/",
    descricao:
      "Armário aéreo de 3 portas com nichos abertos para temperos e utensílios. Solução vertical perfeita para liberar a bancada de cozinhas compactas.",
    marca: "Móveis Bechara",
    keywords: ["armário aéreo", "armário de cozinha", "nicho cozinha", "cozinha pequena"],
    seoTitle: "Armário Aéreo de Cozinha 3 Portas com Nichos | Oferta",
    seoDescription:
      "Armário aéreo de cozinha 3 portas com nichos por R$ 389,90. Libere a bancada e organize a cozinha pequena. Confira na Shopee.",
  },

  // -------------------------- GUARDA-ROUPAS ---------------------------------
  {
    id: "p-003",
    slug: "guarda-roupa-casal-6-portas-mdp",
    category: "guarda-roupas",
    name: "Guarda-Roupa Casal 6 Portas 3 Gavetas MDP",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/guarda-roupa-casal-6-portas.webp",
    displayImage:
      "https://images.pexels.com/photos/6527064/pexels-photo-6527064.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Guarda-roupa de casal branco com 6 portas posicionado ao lado da cama em quarto iluminado",
    rating: 4.8,
    reviews: 5210,
    discount: 28,
    price: 1199.9,
    originalPrice: 1659.9,
    badge: "Premium",
    platform: "Mercado Livre",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://www.mercadolivre.com.br/",
    descricao:
      "Guarda-roupa de casal em MDP com 6 portas, 3 gavetas e espelho central. Acabamento amadeirado resistente e interior planejado com cabideiros e prateleiras.",
    marca: "Araplac",
    keywords: ["guarda-roupa casal", "guarda-roupa 6 portas", "guarda-roupa mdp", "roupeiro casal"],
    seoTitle: "Guarda-Roupa Casal 6 Portas 3 Gavetas MDP | Oferta",
    seoDescription:
      "Guarda-roupa casal 6 portas com espelho por R$ 1.199,90. MDP resistente, interior planejado. Frete grátis no Mercado Livre.",
  },

  // ---------------------------- PAINÉIS / RACK ------------------------------
  {
    id: "p-004",
    slug: "painel-rack-tv-65-polegadas",
    category: "paineis",
    name: "Conjunto Rack com Painel para TV até 65 Polegadas",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/painel-rack-tv-65.webp",
    displayImage:
      "https://images.pexels.com/photos/7174113/pexels-photo-7174113.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Sala de estar com rack e painel para TV grande junto ao sofá",
    rating: 4.7,
    reviews: 2740,
    discount: 30,
    price: 699.9,
    originalPrice: 999.9,
    badge: "Tendência",
    platform: "Shopee",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://shopee.com.br/",
    descricao:
      "Conjunto rack + painel para TVs de até 65''. Estrutura em MDP com nichos e LED opcional. Visual clean que valoriza qualquer sala de estar.",
    marca: "Caemmun",
    keywords: ["painel para tv", "rack com painel", "painel 65 polegadas", "rack sala"],
    seoTitle: "Rack com Painel para TV até 65 Polegadas | Oferta",
    seoDescription:
      "Conjunto rack com painel para TV 65'' por R$ 699,90. Visual clean com nichos. Confira a oferta na Shopee com frete grátis.",
  },

  // -------------------------------- SOFÁS -----------------------------------
  {
    id: "p-005",
    slug: "sofa-retratil-3-lugares-suede",
    category: "sofas",
    name: "Sofá Retrátil e Reclinável 3 Lugares Suede",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/sofa-retratil-3-lugares.webp",
    displayImage:
      "https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Sofá confortável em sala de estar moderna e espaçosa com decoração elegante",
    rating: 4.6,
    reviews: 1980,
    discount: 22,
    price: 1899.9,
    originalPrice: 2449.9,
    badge: "Conforto",
    platform: "Mercado Livre",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://www.mercadolivre.com.br/",
    descricao:
      "Sofá retrátil e reclinável de 3 lugares revestido em suede premium. Assentos com molas ensacadas e espuma D33 para conforto duradouro.",
    marca: "Linoforte",
    keywords: ["sofá retrátil", "sofá reclinável", "sofá 3 lugares", "sofá suede"],
    seoTitle: "Sofá Retrátil Reclinável 3 Lugares Suede | Oferta",
    seoDescription:
      "Sofá retrátil e reclinável 3 lugares em suede por R$ 1.899,90. Conforto com molas ensacadas. Frete grátis no Mercado Livre.",
  },

  // ----------------------------- HOME OFFICE --------------------------------
  {
    id: "p-006",
    slug: "escrivaninha-home-office-gavetas",
    category: "home-office",
    name: "Escrivaninha Home Office com 2 Gavetas e Prateleira",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/escrivaninha-home-office.webp",
    displayImage:
      "https://images.pexels.com/photos/5644330/pexels-photo-5644330.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Home office iluminado com escrivaninha organizada e cadeira amarela",
    rating: 4.5,
    reviews: 1130,
    discount: 27,
    price: 329.9,
    originalPrice: 449.9,
    badge: "Produtividade",
    platform: "Shopee",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://shopee.com.br/",
    descricao:
      "Escrivaninha compacta com 2 gavetas e prateleira de apoio. Tamanho ideal para cantos e quartos, organiza o home office sem ocupar espaço.",
    marca: "EI Móveis",
    keywords: ["escrivaninha", "mesa home office", "mesa de computador", "home office barato"],
    seoTitle: "Escrivaninha Home Office 2 Gavetas | Oferta",
    seoDescription:
      "Escrivaninha home office com 2 gavetas e prateleira por R$ 329,90. Compacta e organizada. Confira a oferta na Shopee.",
  },
  {
    id: "p-007",
    slug: "cadeira-gamer-ergonomica-reclinavel",
    category: "home-office",
    name: "Cadeira Gamer Ergonômica Reclinável com Apoio Lombar",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/cadeira-gamer-ergonomica.webp",
    displayImage:
      "https://images.pexels.com/photos/3958959/pexels-photo-3958959.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Sala de escritório com cadeira de couro e mesa próxima a parede azul",
    rating: 4.7,
    reviews: 4320,
    discount: 35,
    price: 749.9,
    originalPrice: 1149.9,
    badge: "Ergonômica",
    platform: "Mercado Livre",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://www.mercadolivre.com.br/",
    descricao:
      "Cadeira gamer ergonômica com encosto reclinável até 180°, apoio lombar e almofada de pescoço. Ideal para longas jornadas no home office.",
    marca: "ThunderX3",
    keywords: ["cadeira gamer", "cadeira ergonômica", "cadeira escritório", "cadeira home office"],
    seoTitle: "Cadeira Gamer Ergonômica Reclinável | Oferta",
    seoDescription:
      "Cadeira gamer ergonômica reclinável com apoio lombar por R$ 749,90. Conforto para o home office. Frete grátis no Mercado Livre.",
  },

  // ---------------------------- ÁREA EXTERNA --------------------------------
  {
    id: "p-008",
    slug: "conjunto-mesa-cadeiras-area-externa",
    category: "area-externa",
    name: "Conjunto Mesa com 4 Cadeiras para Área Externa em Fibra",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/conjunto-area-externa.webp",
    displayImage:
      "https://images.pexels.com/photos/8135496/pexels-photo-8135496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Ambiente integrado e arejado com móveis modernos para área externa",
    rating: 4.5,
    reviews: 860,
    discount: 20,
    price: 1299.9,
    originalPrice: 1629.9,
    badge: "Resistente ao Tempo",
    platform: "Shopee",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://shopee.com.br/",
    descricao:
      "Conjunto de mesa com 4 cadeiras em fibra sintética e alumínio, resistente a sol e chuva. Perfeito para varandas, jardins e áreas gourmet.",
    marca: "MoveisBrasil",
    keywords: ["móveis área externa", "mesa varanda", "conjunto jardim", "móveis de fibra"],
    seoTitle: "Conjunto Mesa 4 Cadeiras Área Externa Fibra | Oferta",
    seoDescription:
      "Conjunto mesa com 4 cadeiras em fibra para área externa por R$ 1.299,90. Resistente a sol e chuva. Confira na Shopee.",
  },

  // ------------------------------ QUARTOS -----------------------------------
  {
    id: "p-009",
    slug: "cama-box-bau-casal-bicama",
    category: "quartos",
    name: "Cama Box Baú Casal com Bicama Auxiliar",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/cama-box-bau-casal.webp",
    displayImage:
      "https://images.pexels.com/photos/7587809/pexels-photo-7587809.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Quarto aconchegante com design moderno, elementos de madeira e luz natural",
    rating: 4.6,
    reviews: 1670,
    discount: 24,
    price: 1099.9,
    originalPrice: 1449.9,
    badge: "Espaço Extra",
    platform: "Mercado Livre",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://www.mercadolivre.com.br/",
    descricao:
      "Cama box baú de casal com amplo espaço de armazenamento e bicama auxiliar. Une conforto e organização para quartos de casal.",
    marca: "Ortobom",
    keywords: ["cama box baú", "cama casal", "bicama", "cama com gavetão"],
    seoTitle: "Cama Box Baú Casal com Bicama | Oferta",
    seoDescription:
      "Cama box baú casal com bicama auxiliar por R$ 1.099,90. Armazenamento e conforto. Frete grátis no Mercado Livre.",
  },

  // ------------- ELETRODOMÉSTICOS (CROSS-SELL POR CÔMODO) -------------------
  {
    id: "p-010",
    slug: "geladeira-frost-free-frost-360l",
    category: "eletrodomesticos",
    name: "Geladeira Frost Free Duplex 360L Inox",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/geladeira-frost-free-360l.webp",
    displayImage:
      "https://images.pexels.com/photos/3958962/pexels-photo-3958962.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Cozinha moderna e espaçosa com eletrodomésticos de aço inox e geladeira",
    rating: 4.8,
    reviews: 6540,
    discount: 26,
    price: 2799.9,
    originalPrice: 3799.9,
    badge: "Econômica A+",
    platform: "Mercado Livre",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://www.mercadolivre.com.br/",
    descricao:
      "Geladeira frost free duplex de 360 litros, acabamento inox e baixo consumo de energia. Prateleiras reguláveis e gavetão para frutas e legumes.",
    marca: "Brastemp",
    keywords: ["geladeira frost free", "geladeira duplex", "geladeira inox", "refrigerador 360l"],
    seoTitle: "Geladeira Frost Free Duplex 360L Inox | Oferta",
    seoDescription:
      "Geladeira frost free duplex 360L inox por R$ 2.799,90. Baixo consumo e muito espaço. Frete grátis no Mercado Livre.",
  },
  {
    id: "p-011",
    slug: "micro-ondas-30l-espelhado",
    category: "eletrodomesticos",
    name: "Micro-ondas 30 Litros Espelhado com Grill",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/micro-ondas-30l.webp",
    displayImage:
      "https://images.pexels.com/photos/4119841/pexels-photo-4119841.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Bancada de cozinha com armários de madeira e eletrodoméstico em aço inox",
    rating: 4.7,
    reviews: 3890,
    discount: 30,
    price: 649.9,
    originalPrice: 929.9,
    badge: "Cross-Sell",
    platform: "Shopee",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://shopee.com.br/",
    descricao:
      "Micro-ondas de 30 litros com função grill, painel espelhado e receitas pré-programadas. Combina com qualquer cozinha planejada.",
    marca: "Electrolux",
    keywords: ["micro-ondas 30 litros", "micro-ondas espelhado", "micro-ondas grill"],
    seoTitle: "Micro-ondas 30L Espelhado com Grill | Oferta",
    seoDescription:
      "Micro-ondas 30 litros espelhado com grill por R$ 649,90. Painel moderno e prático. Confira a oferta na Shopee.",
  },
  {
    id: "p-012",
    slug: "fogao-5-bocas-mesa-vidro",
    category: "eletrodomesticos",
    name: "Fogão 5 Bocas com Mesa de Vidro e Acendimento Automático",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/fogao-5-bocas.webp",
    displayImage:
      "https://images.pexels.com/photos/6956119/pexels-photo-6956119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Forno contemporâneo e fogão a gás sob prateleiras de madeira na cozinha",
    rating: 4.6,
    reviews: 2110,
    discount: 23,
    price: 1149.9,
    originalPrice: 1499.9,
    badge: "Cross-Sell",
    platform: "Mercado Livre",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://www.mercadolivre.com.br/",
    descricao:
      "Fogão de 5 bocas com mesa de vidro temperado, acendimento automático e forno autolimpante. Acabamento que valoriza a cozinha.",
    marca: "Atlas",
    keywords: ["fogão 5 bocas", "fogão mesa de vidro", "fogão acendimento automático"],
    seoTitle: "Fogão 5 Bocas Mesa de Vidro | Oferta",
    seoDescription:
      "Fogão 5 bocas com mesa de vidro e acendimento automático por R$ 1.149,90. Forno autolimpante. Frete grátis no Mercado Livre.",
  },
  {
    id: "p-013",
    slug: "airfryer-fritadeira-eletrica-5l",
    category: "eletrodomesticos",
    name: "Air Fryer Fritadeira Elétrica Sem Óleo 5 Litros Digital",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/airfryer-5l.webp",
    displayImage:
      "https://images.pexels.com/photos/4119836/pexels-photo-4119836.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Cozinha moderna e espaçosa com armários de madeira e bancada com eletrodomésticos",
    rating: 4.8,
    reviews: 9120,
    discount: 38,
    price: 379.9,
    originalPrice: 619.9,
    badge: "Queridinha",
    platform: "Shopee",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://shopee.com.br/",
    descricao:
      "Air fryer digital de 5 litros com painel touch, timer e desligamento automático. Comida crocante usando até 90% menos óleo.",
    marca: "Mondial",
    keywords: ["air fryer", "fritadeira sem óleo", "airfryer 5 litros", "fritadeira elétrica"],
    seoTitle: "Air Fryer Digital 5 Litros Sem Óleo | Oferta",
    seoDescription:
      "Air fryer digital 5 litros sem óleo por R$ 379,90. Painel touch e timer. Confira a oferta na Shopee com cupom.",
  },
  {
    id: "p-014",
    slug: "ar-condicionado-split-12000-inverter",
    category: "eletrodomesticos",
    name: "Ar-Condicionado Split Inverter 12.000 BTUs Frio",
    // INSERIR_AQUI_O_CAMINHO_DA_IMAGEM_EM_IMAGENS_PRODUTOS
    imageFile: "/imagens/produtos/ar-condicionado-split-12000.webp",
    displayImage:
      "https://images.pexels.com/photos/6835154/pexels-photo-6835154.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    alt: "Cozinha clara com eletrodomésticos de aço inox e armários brancos",
    rating: 4.7,
    reviews: 4010,
    discount: 21,
    price: 1899.9,
    originalPrice: 2399.9,
    badge: "Cross-Sell",
    platform: "Mercado Livre",
    // INSERIR_AQUI_O_LINK_DE_AFILIADO
    affiliateLink: "https://www.mercadolivre.com.br/",
    descricao:
      "Ar-condicionado split inverter 12.000 BTUs com baixo consumo, operação silenciosa e filtro antibactéria. Ideal para quartos e salas.",
    marca: "LG",
    keywords: ["ar condicionado split", "split inverter", "ar 12000 btus", "ar condicionado quarto"],
    seoTitle: "Ar-Condicionado Split Inverter 12.000 BTUs | Oferta",
    seoDescription:
      "Ar-condicionado split inverter 12.000 BTUs frio por R$ 1.899,90. Econômico e silencioso. Frete grátis no Mercado Livre.",
  },
];

// ============================ HELPERS DE ACESSO =============================

/** Busca um produto pelo slug (usado nas rotas /confirmar-estoque/[slug]) */
export const getProductBySlug = (slug: string): Product | undefined =>
  products.find((p) => p.slug === slug);

/** Filtra produtos por uma ou várias categorias */
export const getProductsByCategory = (
  category?: ProductCategory | ProductCategory[]
): Product[] => {
  if (!category) return products;
  const cats = Array.isArray(category) ? category : [category];
  return products.filter((p) => cats.includes(p.category));
};

/** Retorna produtos a partir de uma lista explícita de slugs (cross-sell) */
export const getProductsBySlugs = (slugs: string[]): Product[] =>
  slugs
    .map((slug) => products.find((p) => p.slug === slug))
    .filter((p): p is Product => Boolean(p));

/** Lista única de categorias presentes nos produtos */
export const allCategories = Array.from(
  new Set(products.map((p) => p.category))
) as ProductCategory[];

/** Formata valor em Real brasileiro */
export const formatBRL = (value: number): string =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
